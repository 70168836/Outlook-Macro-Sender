
import os
import smtplib
from email.message import EmailMessage
from datetime import datetime

# Настройки
FOLDER_PATH = "C:/Путь/К/Папке"
SMTP_SERVER = "smtp.your-email.com"
SMTP_PORT = 587
EMAIL_ADDRESS = "your_email@example.com"
EMAIL_PASSWORD = "your_password"

def send_email(subject, recipient, cc, attachment_path):
    msg = EmailMessage()
    msg["From"] = EMAIL_ADDRESS
    msg["To"] = recipient
    msg["Cc"] = cc
    msg["Subject"] = subject
    msg.set_content(f"Во вложении файл: {subject}")

    with open(attachment_path, "rb") as f:
        file_data = f.read()
        file_name = os.path.basename(attachment_path)
        msg.add_attachment(file_data, maintype="application", subtype="octet-stream", filename=file_name)

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as smtp:
        smtp.starttls()
        smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        smtp.send_message(msg)
        print(f"Отправлено: {file_name} → {recipient}")

def main():
    if not os.path.exists(FOLDER_PATH):
        print("Папка не найдена.")
        return

    files = os.listdir(FOLDER_PATH)
    if not files:
        print("Файлы не найдены.")
        return

    for file_name in files:
        file_path = os.path.join(FOLDER_PATH, file_name)

        if not os.path.isfile(file_path):
            continue

        if "лифт" in file_name.lower():
            to = "Dispetcher_CAPEX@cg-living.ru"
            cc = "kuzmich.da@cg-living.ru"
        else:
            to = "parking5@cg-living.ru, parking@cg-living.ru, parking2@cg-living.ru"
            cc = "kuzmich.da@cg-living.ru"

        send_email(file_name, to, cc, file_path)

if __name__ == "__main__":
    now = datetime.now().strftime("%H:%M")
    if now in ["21:30", "00:01"]:
        main()
